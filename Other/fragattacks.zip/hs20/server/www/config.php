<?php
$osu_root = "/home/user/hs20-server";
$osu_db = "sqlite:$osu_root/AS/DB/eap_user.db";
$t_c_file = "$osu_root/terms-and-conditions";
$t_c_timestamp = 123456789;
$hostapd_ctrl = "udg:///home/user/hs20-server/AS/ctrl/as"
?>
