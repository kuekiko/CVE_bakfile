#ifndef HELPERS_H_
#define HELPERS_H_

bool pin_cpu(int cpu);

#endif /*! HELPERS_H_ */
