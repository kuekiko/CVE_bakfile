The two firmware images in this directory are patched so the sequence number
of injected frames is not overwritten. This patch is on top of the public
open ath9k_htc firmware.
