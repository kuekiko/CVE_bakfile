This is an experimental library that I internally use in some projects. One day this might be useful for others too.
