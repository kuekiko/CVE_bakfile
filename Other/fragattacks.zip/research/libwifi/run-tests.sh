#!/bin/bash
cd ..
python -m pytest $@
