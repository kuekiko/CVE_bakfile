<html>
<head>
<title>Hotspot 2.0 - public and free hotspot - remediation</title>
</head>
<body>

<h3>Hotspot 2.0 - public and free hotspot</h3>

<p>Terms and conditions have changed. You need to accept the new terms
to continue using this network.</p>

<p>Terms and conditions..</p>

<?php
echo "<a href=\"redirect.php?id=" . $_GET["session_id"] . "\">Accept</a><br>\n";
?>

</body>
</html>
